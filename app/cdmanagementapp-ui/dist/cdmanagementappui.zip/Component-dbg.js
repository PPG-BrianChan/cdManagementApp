sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("cdmanagementappui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);